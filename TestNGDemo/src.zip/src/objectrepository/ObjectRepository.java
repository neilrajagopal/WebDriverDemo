package objectrepository;

public class ObjectRepository {
	//Login Page
	public static String txtUserName="userName";
	public static String txtPassword="password";
	public static String btnLogin="login";
	public static String btnLoginxPath="//input[@name='login']";
	
	//Booking Tickets
	public static String radTripType="tripType";
	public static String selFromPortl="fromPort";
	
	//Logout
	public static String lnkSignOff="SIGN-OFF";

}
